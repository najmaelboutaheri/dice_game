package com.bo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class GameState {
    private int[] diceResults = new int[3];
    private boolean gameOver;
    private Set<Integer> rolledDice = new HashSet<>();
    private List<Message> messages = new ArrayList<>();
    private User user;

    public GameState() {
        initDiceResults();
        this.gameOver = false;
    }
    
    public GameState(User user) {
        this.user = user;
        initDiceResults();
        this.gameOver = false;
    }

    private void initDiceResults() {
        for (int i = 0; i < diceResults.length; i++) {
            diceResults[i] = -1; // Initialisation à une valeur indiquant que le dé n'a pas été lancé
        }
    }

    public void reinit() {
        initDiceResults();
        rolledDice.clear();
        gameOver = false;
        messages.clear();
        user.setScore(0);
        user.setCompteurLancer(0);
    }

    public Set<Integer> getRolledDice() {
        return rolledDice;
    }

    public void setRolledDice(Set<Integer> rolledDice) {
        this.rolledDice = rolledDice;
    }

    public List<Message> getMessages() {
        return messages;
    }

    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setDiceResults(int[] diceResults) {
        this.diceResults = diceResults;
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public void setGameOver(boolean gameOver) {
        this.gameOver = gameOver;
    }

    public boolean isDiceRolled(int diceNumber) {
        return rolledDice.contains(diceNumber);
    }

    public void setDiceResult(int diceNumber, int result) {
        diceResults[diceNumber - 1] = result;
        rolledDice.add(diceNumber);
    }

    public int getDiceResult(int diceNumber) {
        return diceResults[diceNumber - 1];
    }

    public int[] getDiceResults() {
        return diceResults;
    }

    public boolean allDiceRolled() {
        return rolledDice.size() == 3;
    }
}


