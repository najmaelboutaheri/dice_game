package com.web.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import com.bo.GameState;
import com.bo.Message;
import com.bo.User;
import java.util.Random;
@WebServlet("/back/GameServlet")
public class GameServlet extends HttpServlet {

    protected void play(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        GameState gameState = (GameState) session.getAttribute("gameState");

        if (gameState == null) {
            gameState = new GameState(user);
            session.setAttribute("gameState", gameState);
        }

        List<Message> messages = new ArrayList<>();

        // Vérifier si le jeu est terminé
        if (gameState.isGameOver()) {
            getServletContext().getRequestDispatcher("/WEB-INF/vues/pages/results.jsp").forward(request, response);
            return;
        }

        // Récupérer le numéro de dé à lancer
        int diceNumber;
        try {
            diceNumber = getDiceNumber(request);
        } catch (IllegalArgumentException e) {
            messages.add(new Message("Veuillez choisir un nombre valide !", Message.ERROR));
            request.setAttribute("messages", messages);
            getServletContext().getRequestDispatcher("/WEB-INF/vues/back/userHome.jsp").forward(request, response);
            return;
        }

        // Vérifier si le dé a déjà été lancé
        if (gameState.isDiceRolled(diceNumber)) {
            endGame(request, response, user, gameState, -1);
            return;
        }

        // Lancer le dé et obtenir le résultat
        int result = 1 + new Random().nextInt(6); // Générer un nouveau résultat de dé
        gameState.setDiceResult(diceNumber, result);

        // Vérifier les conditions de fin de jeu
        if ((diceNumber == 1 && (result == 6 || result == 5 || result == gameState.getDiceResults()[1] || result == gameState.getDiceResults()[2]))
            || (diceNumber == 2 && (result == 6 || result == 1 || result == gameState.getDiceResults()[0] || result == gameState.getDiceResults()[2]))
            || (diceNumber == 3 && (result == 1 || result == 2 || result == gameState.getDiceResults()[0] || result == gameState.getDiceResults()[1]))) {
            endGame(request, response, user, gameState, 0);
            return;
        }

        // Vérifier si tous les dés ont été lancés
        if (gameState.allDiceRolled()) {
            int score = calculateScore(gameState);
            if (score != 0) {
                messages.add(new Message("Vous avez gagné !", Message.INFO));
            } else {
                messages.add(new Message("Jeu terminé ", Message.INFO));
            }
            endGame(request, response, user, gameState, score);
            return;
        }

        // Ajouter un message pour le résultat du dé
        messages.add(new Message("Vous obtenez " + result + " pour Dé Numero " + diceNumber, Message.INFO));
        request.setAttribute("messages", messages);
        getServletContext().getRequestDispatcher("/WEB-INF/vues/back/userHome.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        play(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        play(request, response);
    }

    private int getDiceNumber(HttpServletRequest request) throws IllegalArgumentException {
        String diceNumberStr = request.getParameter("diceNumber");
        int diceNumber;
        try {
            diceNumber = Integer.parseInt(diceNumberStr);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid dice number");
        }
        if (diceNumber < 1 || diceNumber > 3) {
            throw new IllegalArgumentException("Invalid dice number");
        }
        return diceNumber;
    }

    private int calculateScore(GameState gameState) {
        int result1 = gameState.getDiceResults()[0];
        int result2 = gameState.getDiceResults()[1];
        int result3 = gameState.getDiceResults()[2];

        if (result1 < result2 && result2 < result3) {
            return result1 + result2 + result3;
        } else {
            return 0;
        }
    }

    private void endGame(HttpServletRequest request, HttpServletResponse response, User user, GameState gameState, int score) throws ServletException, IOException {
        user.setScore(score);
        if (score > user.getBestScore()) {
            user.setBestScore(score);
        }
        gameState.setGameOver(true);
        request.setAttribute("currentScore", user.getScore());
        request.setAttribute("bestScore", user.getBestScore());
        request.getSession().setAttribute("gameState", gameState);
        getServletContext().getRequestDispatcher("/WEB-INF/vues/pages/results.jsp").forward(request, response);
    }
}
